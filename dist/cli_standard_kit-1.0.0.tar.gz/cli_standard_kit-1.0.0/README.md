# ⚙️ cli-standard-kit  
> Self-installing Python CLI for standardized command-line projects  
> Python projelerinde tutarlı CLI yapısı kurmak için kendi kendini kuran araç  

[![PyPI Version](https://img.shields.io/pypi/v/cli-standard-kit)](https://pypi.org/project/cli-standard-kit/)
[![Python Versions](https://img.shields.io/pypi/pyversions/cli-standard-kit)](https://pypi.org/project/cli-standard-kit/)
[![License](https://img.shields.io/pypi/l/cli-standard-kit)](LICENSE)
[![Template](https://img.shields.io/badge/Template-cookiecutter--cli--standard--kit-orange)](https://github.com/c3nk/cookiecutter-cli-standard-kit)
[![Maintainer](https://img.shields.io/badge/Maintainer-Cenk%20Kabahasanoglu-blue)](https://github.com/c3nk)

---

## 🇬🇧 Overview  
**cli-standard-kit** is a self-installing CLI that automatically creates new Python command-line applications  
based on the [`cookiecutter-cli-standard-kit`](https://github.com/c3nk/cookiecutter-cli-standard-kit) template.  

It:
- Initializes a new project structure  
- Sets up Git and commits  
- Creates a `.venv` virtual environment  
- Provides a ready-to-run CLI foundation  

## 🇹🇷 Genel Bakış  
**cli-standard-kit**, [`cookiecutter-cli-standard-kit`](https://github.com/c3nk/cookiecutter-cli-standard-kit)  
şablonunu kullanarak yeni Python CLI projelerini **tek komutla kuran** araçtır.  

Otomatik olarak:  
- Yeni proje dizinini oluşturur  
- Git deposunu başlatır ve ilk commit'i yapar  
- `.venv` sanal ortamını kurar  
- Kullanıma hazır standart yapı sağlar  

---

## 🚀 Quick Start  

```bash
pip install cli-standard-kit
cli-standard-kit init myproject