from .init_project import run_init

def main():
    run_init()

if __name__ == "__main__":
    main()
